<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\PostsModel;


class AssetDataController extends BaseController
{

    protected $manageDataDb;

    public function __construct()
    {

        $this->manageDataDb = new PostsModel();
    }

    public function manage_data()
    {


        if ($this->request->getMethod() == 'post') {

            $params['draw'] = $_REQUEST['draw'];
            $start = $_REQUEST['start'];
            $length = $_REQUEST['length'];
            /* If we pass any extra data in request from ajax */
            //$value1 = isset($_REQUEST['key1'])?$_REQUEST['key1']:"";

            /* Value we will get from typing in search */
            $search_value = $_REQUEST['search']['value'];

            if (!empty($search_value)) {
            $manageData = $this->manageDataDb->distinct()
                ->select('ttg_post.id, ttg_post.userid, ttg_post.files, ttg_post.time, ttg_post.uid, ttg_post.crn, ttg_post.verifyStatus, ttg_post.uid, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')
                ->like('ttg_post.userid', $search_value)
                ->orlike('ttg_post.crn', $search_value)
                ->orlike('ttg_post.uid', $search_value)
                ->orlike('ttg_login.country', $search_value)
                ->orlike('ttg_post.verifyStatus', $search_value)
                ->orderBy('ttg_post.id', 'desc')->offset($start)->findAll($length);
            $count = $this->manageDataDb->distinct()
                ->select('ttg_post.*, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')
                ->like('ttg_post.userid', $search_value)
                ->orlike('ttg_post.crn', $search_value)
                ->orlike('ttg_post.uid', $search_value)
                ->orlike('ttg_login.country', $search_value)
                ->orlike('ttg_post.verifyStatus', $search_value)
                ->orderBy('ttg_post.id', 'desc')->countAllResults();
            } else {
                $manageData = $this->manageDataDb->distinct()
                ->select('ttg_post.id, ttg_post.userid, ttg_post.files, ttg_post.time, ttg_post.uid, ttg_post.crn, ttg_post.verifyStatus, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')
                ->orderBy('ttg_post.id', 'desc')->offset($start)->findAll($length);
            $count = $this->manageDataDb->distinct()
                ->select('ttg_post.*, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')
                ->orderBy('ttg_post.id', 'desc')->countAllResults();
            }



            // if(!empty($search_value)){
            //     // If we have value in search, searching by id, name, email, mobile

            //     // count all data
            //     // $total_count = $this->db->query("SELECT * from tbl_students WHERE id like '%".$search_value."%' OR name like '%".$search_value."%' OR email like '%".$search_value."%' OR mobile like '%".$search_value."%'")->getResult();

            //     // $data = $this->db->query("SELECT * from tbl_students WHERE id like '%".$search_value."%' OR name like '%".$search_value."%' OR email like '%".$search_value."%' OR mobile like '%".$search_value."%' limit $start, $length")->getResult();
            // }else{
            //     // count all data
            //     // $total_count = $this->db->query("SELECT * from tbl_students")->getResult();

            //     // get per page data
            //     // $data = $this->db->query("SELECT * from tbl_students limit $start, $length")->getResult();
            // }
            $checkBoxHtml = '<div class="custom-control custom-control-sm custom-checkbox notext">
                        <input type="checkbox" class="custom-control-input" value="uid1" id="uid1">
                        <label class="custom-control-label" for="uid1"></label>
                    </div>';
            $actionsHtml = '<ul class="nk-tb-actions gx-1"><li>
                            <div class="drodown">
                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <ul class="link-list-opt no-bdr">
                                    <li><a href="#"><em class="icon ni ni-eye"></em><span>View Details</span></a></li>
                                    <li><a href="#"><em class="icon ni ni-share"></em><span>Share</span></a></li>
                                    <li><a href="#"><em class="icon ni ni-file-pdf"></em><span>PDF</span></a></li>
                                    <li><a href="#"><em class="icon ni ni-file-docs"></em><span>Excel</span></a></li>
                                        <li><a href="#"><em class="icon ni ni-trash"></em><span>Delete</span></a></li>
                                       
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>';

            foreach ($manageData as $key => $manage) {
                $manageData[$key]['id'] = str_replace("uid1", $manage['id'], $checkBoxHtml);
                $manageData[$key]['actions'] = $actionsHtml;

                $manageData[$key]['time'] = '<span>' . date("d M Y, g:s A", $manage['time']) . '</span>';
                $files = json_decode($manage['files']);
                $filesCount = count($files);
                $manageData[$key]['files'] = $filesCount;
                if ($manage['verifyStatus'] == 0) {
                    $manageData[$key]['verifyStatus'] =  '<span class="badge badge-dot badge-dot-xs badge-warning">Pending</span>';
                }
                if ($manage['verifyStatus'] == 1) {
                    $manageData[$key]['verifyStatus'] =  '<span class="badge badge-dot badge-dot-xs badge-danger">Varified</span>';
                }
                if ($manage['verifyStatus'] == 2) {
                    $manageData[$key]['verifyStatus'] =  '<span class="badge badge-dot badge-dot-xs badge-danger">Objected</span>';
                }
                if ($manage['verifyStatus'] == 3) {
                    $manageData[$key]['verifyStatus'] =  '<span class="badge badge-dot badge-dot-xs badge-danger">Re-Verified</span>';
                }
                if ($manage['verifyStatus'] == 4) {
                    $manageData[$key]['verifyStatus'] =  '<span class="badge badge-dot badge-dot-xs badge-danger">Re-Objected</span>';
                }
            }

            $json_data = array(
                "draw" => intval($params['draw']),
                "recordsTotal" => $count,
                "recordsFiltered" => $count,
                "data" => $manageData   // total data array
            );

            return json_encode($json_data);
        }
        // $this->data['managedata'] = $this->manageDataDb->orderBy('id', 'desc')->findAll(100);
        return view('Dashboard/Admin/manage_data', $this->data);
    }

    public function defect_analysis()
    {
        if ($this->request->getMethod() == 'post') {

            $params['draw'] = $_REQUEST['draw'];
            $start = $_REQUEST['start'];
            $length = $_REQUEST['length'];
            /* If we pass any extra data in request from ajax */
            //$value1 = isset($_REQUEST['key1'])?$_REQUEST['key1']:"";

            /* Value we will get from typing in search */
            $search_value = $_REQUEST['search']['value'];

            if (!empty($search_value)) {
            $defect_analysis = $this->manageDataDb->distinct()
                ->select('ttg_post.id, ttg_post.userid, ttg_post.files, ttg_post.time, ttg_post.uid, ttg_post.crn, ttg_post.device_type, ttg_post.defect, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')
                ->like('ttg_post.userid', $search_value)
                ->orlike('ttg_post.crn', $search_value)
                ->orlike('ttg_post.uid', $search_value)
                ->orlike('ttg_post.device_type', $search_value)
                ->orlike('ttg_post.defect', $search_value)
                ->orderBy('ttg_post.id', 'desc')->offset($start)->findAll($length);
            $count = $this->manageDataDb->distinct()
                ->select('ttg_post.*, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')
                ->like('ttg_post.userid', $search_value)
                ->orlike('ttg_post.crn', $search_value)
                ->orlike('ttg_post.uid', $search_value)
                ->orlike('ttg_post.device_type', $search_value)
                ->orlike('ttg_post.defect', $search_value)
                ->orderBy('ttg_post.id', 'desc')->countAllResults();
            } else {
                $defect_analysis = $this->manageDataDb->distinct()
                ->select('ttg_post.id, ttg_post.userid, ttg_post.files, ttg_post.time, ttg_post.uid, ttg_post.crn, ttg_post.device_type, ttg_post.defect, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')
                ->orderBy('ttg_post.id', 'desc')->offset($start)->findAll($length);
            $count = $this->manageDataDb->distinct()
                ->select('ttg_post.*, ttg_login.country as userCountry')
                ->join('ttg_login', 'ttg_login.id = ttg_post.userid')           
                ->orderBy('ttg_post.id', 'desc')->countAllResults();
            }

            // if(!empty($search_value)){
            //     // If we have value in search, searching by id, name, email, mobile

            //     // count all data
            //     // $total_count = $this->db->query("SELECT * from tbl_students WHERE id like '%".$search_value."%' OR name like '%".$search_value."%' OR email like '%".$search_value."%' OR mobile like '%".$search_value."%'")->getResult();

            //     // $data = $this->db->query("SELECT * from tbl_students WHERE id like '%".$search_value."%' OR name like '%".$search_value."%' OR email like '%".$search_value."%' OR mobile like '%".$search_value."%' limit $start, $length")->getResult();
            // }else{
            //     // count all data
            //     // $total_count = $this->db->query("SELECT * from tbl_students")->getResult();

            //     // get per page data
            //     // $data = $this->db->query("SELECT * from tbl_students limit $start, $length")->getResult();
            // }
            $checkBoxHtml = '<div class="custom-control custom-control-sm custom-checkbox notext">
                        <input type="checkbox" class="custom-control-input" value="uid1" id="uid1">
                        <label class="custom-control-label" for="uid1"></label>
                    </div>';
            $actionsHtml = '<ul class="nk-tb-actions gx-1"><li>
                            <div class="drodown">
                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <ul class="link-list-opt no-bdr">
                                        <li><a href="#"><em class="icon ni ni-share"></em><span>Share</span></a></li>
                                        <li><a href="#"><em class="icon ni ni-eye"></em><span>View Details</span></a></li>
                                        <li><a href="#"><em class="icon ni ni-trash"></em><span>Delete</span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>';

                    

            foreach ($defect_analysis as $key => $defect) {
                $defect_analysis[$key]['id'] = str_replace("uid1", $defect['id'], $checkBoxHtml);
                $defect_analysis[$key]['actions'] = $actionsHtml;

                $defect_analysis[$key]['time'] = '<span>' . date("d M Y, g:s A", $defect['time']) . '</span>';
                $defect_analysis[$key]['crn'] = '<span data-toggle="modal" data-target="#crnData">'. $defect['crn'] .'</span>';
                // $files = json_decode($defect['files']);
                // $filesCount = count($files);
                // $defect_analysis[$key]['files'] = $filesCount;
            }

            $json_data = array(
                "draw" => intval($params['draw']),
                "recordsTotal" => $count,
                "recordsFiltered" => $count,
                "data" => $defect_analysis   // total data array
            );

            return json_encode($json_data);
        }
        // $this->data['defect_analysis'] = $this->manageDataDb->orderBy('id', 'desc')->findAll(100);
        return view('Dashboard/Admin/defect_analysis', $this->data);
    }
}
